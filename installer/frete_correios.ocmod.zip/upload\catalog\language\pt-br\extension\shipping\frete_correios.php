<?php
// Text
$_['text_title']          = 'Frete Sedex';
$_['text_description']    = 'Frete Sedex';
$_['text_deadline_day']   = 'Prazo de entrega %s dia';
$_['text_deadline_days']  = 'Prazo de entrega %s dias';