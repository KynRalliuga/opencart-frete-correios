<?php
// Text
$_['text_title']          = 'Shippment Sedex';
$_['text_description']    = 'Shippment Sedex';
$_['text_deadline_day']   = 'Deadline %s Day';
$_['text_deadline_days']  = 'Deadline %s Days';